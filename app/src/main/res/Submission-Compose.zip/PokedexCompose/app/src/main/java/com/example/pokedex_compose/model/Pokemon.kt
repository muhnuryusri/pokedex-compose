package com.example.pokedex_compose.model

data class Pokemon (
    val id: Int,
    val name: String,
    val img: String,
    val desc: String,
)